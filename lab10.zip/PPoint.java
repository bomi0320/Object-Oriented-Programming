package kr.ac.kookmin.cs;

/**
    x와 y 값을 받아서 xA, yA 값에 저장하고, 그 값을 출력해주는 메쏘드를 포함한 클래스이다.
*/
public class PPoint {
    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    
    /**
        xA의 게터함수이다.
        @return xA 값
    */
    public int getX() {
        return xA;
    }

    /**
        yA의 게터함수이다.
        @return yA 값
    */
    public int getY() {
        return yA;
    }
}
