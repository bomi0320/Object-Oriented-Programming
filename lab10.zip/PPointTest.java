import kr.ac.kookmin.cs.*;

/**
    main method를 포함한 함수이다.
    PPoint 객체를 만들고 PPoint 클래스의 x 값과 y 값을 출력한다.
*/
class PPointTest {
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}
